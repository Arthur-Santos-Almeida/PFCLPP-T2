Compilar o heuristic.c para um executável chamado heuristic.exe, dentro do próprio diretório:

gcc heuristic.c -o heuristic